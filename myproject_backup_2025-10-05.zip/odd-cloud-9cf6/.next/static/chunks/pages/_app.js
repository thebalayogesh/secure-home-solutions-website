__turbopack_load_page_chunks__("/_app", [
  "static/chunks/4787e_next_dist_compiled_next-devtools_index_9a27b047.js",
  "static/chunks/4787e_next_dist_compiled_303f463f._.js",
  "static/chunks/4787e_next_dist_shared_lib_8854f1ea._.js",
  "static/chunks/4787e_next_dist_client_2923b3ae._.js",
  "static/chunks/4787e_next_dist_522cd8c8._.js",
  "static/chunks/4787e_next_app_6616ca48.js",
  "static/chunks/[next]_entry_page-loader_ts_e2c4c640._.js",
  "static/chunks/a14e7_react-dom_638ad3bb._.js",
  "static/chunks/node_modules__pnpm_fd216e26._.js",
  "static/chunks/[root-of-the-server]__010dee56._.js",
  "static/chunks/pages__app_5771e187._.js",
  "static/chunks/pages__app_33cf25cd._.js"
])
