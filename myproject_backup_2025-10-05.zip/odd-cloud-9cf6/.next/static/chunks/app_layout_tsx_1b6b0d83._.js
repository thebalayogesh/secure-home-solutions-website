(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules__pnpm_31eb7f75._.js",
  "static/chunks/components_1a3d677c._.js",
  "static/chunks/app_globals_73c37791.css"
],
    source: "dynamic"
});
