(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/b2692_react-icons_si_index_mjs_9e215df2._.js",
  "static/chunks/b2692_react-icons_lib_d4addfaa._.js",
  "static/chunks/23f64_lucide-react_dist_esm_icons_f25f2cd4._.js",
  "static/chunks/components_eca4de98._.js"
],
    source: "dynamic"
});
