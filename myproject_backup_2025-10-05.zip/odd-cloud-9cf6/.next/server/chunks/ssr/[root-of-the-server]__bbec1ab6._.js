module.exports = {

"[project]/.next-internal/server/app/page/actions.js [app-rsc] (server actions loader, ecmascript)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
}}),
"[project]/app/layout.tsx [app-rsc] (ecmascript, Next.js Server Component)": ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/layout.tsx [app-rsc] (ecmascript)"));
}),
"[project]/app/not-found.tsx [app-rsc] (ecmascript, Next.js Server Component)": ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/not-found.tsx [app-rsc] (ecmascript)"));
}),
"[project]/data/products.json (json)": ((__turbopack_context__) => {

__turbopack_context__.v(JSON.parse("[{\"id\":\"1\",\"name\":\"Godrej Matrix 3016 (Digi+KL)\",\"price\":\"1,40,899\",\"size\":[\"(cm)90.3(h)x53.6(w)x54.7(d)\",\"(mm)903(h)x536(w)x547(d)\"],\"weight\":\"210kg\",\"volume\":\"112L\",\"category\":[\"250x\"],\"slug\":\"godrej-matrix-3016-digi-kl\",\"description\":\"A premium safe with modern lock mechanisms and high fire resistance.\",\"images\":[\"/images/250x/Godrej-Matrix-3016-1.webp\",\"/images/250x/Godrej-Matrix-3016-2.webp\"],\"tags\":[\"best-seller\",\"featured\"],\"lock_mechanism\":[\"digital\",\"keylock\"]},{\"id\":\"2\",\"name\":\"Godrej Matrix 3016 (KL)\",\"price\":\"1,06,199\",\"size\":[\"(cm)90.3(h)x53.6(w)x54.7(d)\",\"(mm)903(h)x536(w)x547(d)\"],\"weight\":\"210kg\",\"volume\":\"112L\",\"category\":[\"250x\"],\"slug\":\"godrej-matrix-3016-kl\",\"description\":\"A premium safe with modern lock mechanisms and high fire resistance.\",\"images\":[\"/images/250x/Godrej-Matrix-3016-kl-1.webp\",\"/images/250x/Godrej-Matrix-3016-kl-2.webp\"],\"tags\":[\"best-seller\",\"featured\"],\"lock_mechanism\":[\"keylock\"]},{\"id\":\"3\",\"name\":\"Godrej Matrix 2414 (Digi+KL)\",\"price\":\"1,19,499\",\"size\":[\"(cm)74.8(h)x48.6(w)x54.7(d)\",\"(mm)748(h)x486(w)x547(d)\"],\"weight\":\"175kg\",\"volume\":\"78L\",\"category\":[\"250x\"],\"slug\":\"godrej-matrix-2414-digi-kl\",\"description\":\"A premium safe with modern lock mechanisms and high fire resistance.\",\"images\":[\"/images/250x/Godrej-Matrix-2414-1.webp\",\"/images/250x/Godrej-Matrix-2414-2.webp\"],\"tags\":[\"best-seller\",\"featured\"],\"lock_mechanism\":[\"digital\",\"keylock\"]},{\"id\":\"4\",\"name\":\"Godrej Matrix 2414 (KL)\",\"price\":\"90,199\",\"size\":[\"(cm)74.8(h)x48.6(w)x54.7(d)\",\"(mm)748(h)x486(w)x547(d)\"],\"weight\":\"175kg\",\"volume\":\"78L\",\"category\":[\"250x\"],\"slug\":\"godrej-matrix-2414-kl\",\"description\":\"A premium safe with modern lock mechanisms and high fire resistance.\",\"images\":[\"/images/250x/Godrej-Matrix-2414-kl-1.webp\",\"/images/250x/Godrej-Matrix-2414-kl-2.webp\"],\"tags\":[\"best-seller\",\"featured\"],\"lock_mechanism\":[\"keylock\"]},{\"id\":\"5\",\"name\":\"Godrej Matrix 1814 (Digi)\",\"price\":\"96,299\",\"size\":[\"(cm)59.6(h)x48.6(w)x54.7(d)\",\"(mm)596(h)x486(w)x547(d)\"],\"weight\":\"145kg\",\"volume\":\"59L\",\"category\":[\"250x\"],\"slug\":\"godrej-matrix-1814-digi-kl\",\"description\":\"A premium safe with modern lock mechanisms and high fire resistance.\",\"images\":[\"/images/250x/Godrej-Matrix-1814-1.webp\",\"/images/250x/Godrej-Matrix-1814-2.webp\"],\"tags\":[\"best-seller\",\"featured\"],\"lock_mechanism\":[\"digital\",\"keylock\"]},{\"id\":\"6\",\"name\":\"Godrej Matrix 1814 (KL)\",\"price\":\"85,099\",\"size\":[\"(cm)59.6(h)x48.6(w)x54.7(d)\",\"(mm)596(h)x486(w)x547(d)\"],\"weight\":\"145kg\",\"volume\":\"59L\",\"category\":[\"250x\"],\"slug\":\"godrej-matrix-1814-kl\",\"description\":\"A premium safe with modern lock mechanisms and high fire resistance.\",\"images\":[\"/images/250x/Godrej-Matrix-1814-kl-1.webp\",\"/images/250x/Godrej-Matrix-1814-kl-2.webp\"],\"tags\":[\"best-seller\",\"featured\"],\"lock_mechanism\":[\"keylock\"]},{\"id\":\"7\",\"name\":\"Godrej Presidio(KL)\",\"price\":\"69,999\",\"size\":[\"(cm)61.3(h)x43(w)x43(d)\",\"(mm)613(h)x430(w)x430(d)\"],\"weight\":\"98kg\",\"volume\":\" 48.9L\",\"category\":[\"250x\"],\"slug\":\"godrej-presidio-kl\",\"description\":\"A premium safe with modern lock mechanisms and high fire resistance.\",\"images\":[\"/images/250x/Godrej-Presidio-1.webp\",\"/images/250x/Godrej-Presidio-2.webp\"],\"tags\":[\"best-seller\",\"featured\"],\"lock_mechanism\":[\"keylock\"]},{\"id\":\"8\",\"name\":\"Godrej Nx Advanced 560L(Digi+Bio+KL)\",\"price\":\"2,41,849\",\"size\":[\"(cm)158(h)x70(w)x60(d)\",\"(mm)1580(h)x700(w)x600(d)\"],\"weight\":\"270kg\",\"volume\":\" 560L\",\"category\":[\"100x\"],\"slug\":\"godrej-nx-advanced-560l-digi-bio-kl\",\"description\":\"A premium safe with modern lock mechanisms and high fire resistance.\",\"images\":[\"/images/100x/Godrej-Nx-Advanced-560L-1.webp\",\"/images/100x/Godrej-Nx-Advanced-560L-2.webp\"],\"tags\":[\"featured\"],\"lock_mechanism\":[\"digital\",\"biometric\",\"keylock\"]},{\"id\":\"9\",\"name\":\"Godrej Nx Advanced 370L(Digi+Bio+KL)\",\"price\":\"1,99,949\",\"size\":[\"(cm)125(h)x60(w)x60(d)\",\"(mm)1250(h)x600(w)x600(d)\"],\"weight\":\"200kg\",\"volume\":\" 370L\",\"category\":[\"100x\"],\"slug\":\"godrej-nx-advanced-370l-digi-bio-kl\",\"description\":\"A premium safe with modern lock mechanisms and high fire resistance.\",\"images\":[\"/images/100x/Godrej-Nx-Advanced-370l-1.webp\",\"/images/100x/Godrej-Nx-Advanced-370l-2.webp\"],\"tags\":[\"featured\"],\"lock_mechanism\":[\"digital\",\"biometric\",\"keylock\"]},{\"id\":\"10\",\"name\":\"Godrej Nx Advanced 210L(Digi+Bio+KL)\",\"price\":\"1,56,149\",\"size\":[\"(cm)106(h)x50(w)x50(d)\",\"(mm)1060(h)x500(w)x500(d)\"],\"weight\":\"141kg\",\"volume\":\" 210L\",\"category\":[\"100x\"],\"slug\":\"godrej-nx-advanced-210l-digi-bio-kl\",\"description\":\"A premium safe with modern lock mechanisms and high fire resistance.\",\"images\":[\"/images/100x/Godrej-Nx-Advanced-210l-1.webp\",\"/images/100x/Godrej-Nx-Advanced-210l-2.webp\"],\"tags\":[\"featured\"],\"lock_mechanism\":[\"digital\",\"biometric\",\"keylock\"]},{\"id\":\"11\",\"name\":\"Godrej Nx Advanced 160L(Digi+Bio+KL)\",\"price\":\"1,24,049\",\"size\":[\"(cm)80(h)x50(w)x50(d)\",\"(mm)800(h)x500(w)x500(d)\"],\"weight\":\"113kg\",\"volume\":\" 160L\",\"category\":[\"100x\"],\"slug\":\"godrej-nx-advanced-160l-digi-bio-kl\",\"description\":\"A premium safe with modern lock mechanisms and high fire resistance.\",\"images\":[\"/images/100x/Godrej-Nx-Advanced-160l-1.webp\",\"/images/100x/Godrej-Nx-Advanced-160l-2.webp\"],\"tags\":[\"featured\"],\"lock_mechanism\":[\"digital\",\"biometric\",\"keylock\"]},{\"id\":\"12\",\"name\":\"Godrej Rhino Regal(KL)\",\"price\":\"62,899\",\"size\":[\"(cm)61(h)x46(w)x40.7(d)\",\"(mm)610(h)x460(w)x407(d)\"],\"weight\":\"50kg\",\"volume\":\"100L\",\"category\":[\"100x\"],\"slug\":\"godrej-rhino-regal-kl\",\"description\":\"A premium safe with modern lock mechanisms and high fire resistance.\",\"images\":[\"/images/100x/Godrej-Rhino-Regal-1.webp\",\"/images/100x/Godrej-Rhino-Regal-2.webp\"],\"tags\":[\"featured\"],\"lock_mechanism\":[\"keylock\"]},{\"id\":\"13\",\"name\":\"Godrej Rhino Advanced(Digi)\",\"price\":\"54,399\",\"size\":[\"(cm)61(h)x46(w)x41.5(d)\",\"(mm)610(h)x460(w)x415(d)\"],\"weight\":\"52kg\",\"volume\":\"79L\",\"category\":[\"100x\"],\"slug\":\"godrej-rhino-Advanced-digitel\",\"description\":\"A premium safe with modern lock mechanisms and high fire resistance.\",\"images\":[\"/images/100x/Godrej-Rhino-advanced-1.webp\",\"/images/100x/Godrej-Rhino-advanced-2.webp\"],\"tags\":[\"featured\"],\"lock_mechanism\":[\"digitel\"]},{\"id\":\"14\",\"name\":\"Godrej Rhino Advanced(KL)\",\"price\":\"44,299\",\"size\":[\"(cm)61(h)x46(w)x40.7(d)\",\"(mm)610(h)x460(w)x407(d)\"],\"weight\":\"51kg\",\"volume\":\"79L\",\"category\":[\"100x\"],\"slug\":\"godrej-rhino-advanced-kl\",\"description\":\"A premium safe with modern lock mechanisms and high fire resistance.\",\"images\":[\"/images/100x/Godrej-Rhino-advanced-kl-1.webp\",\"/images/100x/Godrej-Rhino-advanced-kl-2.webp\"],\"tags\":[\"featured\"],\"lock_mechanism\":[\"keylock\"]},{\"id\":\"15\",\"name\":\"Godrej Rhino(Digi)\",\"price\":\"36,499\",\"size\":[\"(cm)42.4(h)x46(w)x41.5(d)\",\"(mm)424(h)x460(w)x415(d)\"],\"weight\":\"35kg\",\"volume\":\"55L\",\"category\":[\"100x\"],\"slug\":\"godrej-rhino-digi\",\"description\":\"A premium safe with modern lock mechanisms and high fire resistance.\",\"images\":[\"/images/100x/Godrej-Rhino-digi-1.webp\",\"/images/100x/Godrej-Rhino-digi-2.webp\"],\"tags\":[\"featured\"],\"lock_mechanism\":[\"digitel\"]},{\"id\":\"16\",\"name\":\"Godrej Rhino Advanced(KL)\",\"price\":\"29,599\",\"size\":[\"(cm)42.4(h)x46(w)x40.7(d)\",\"(mm)424(h)x460(w)x407(d)\"],\"weight\":\"35kg\",\"volume\":\"55L\",\"category\":[\"100x\"],\"slug\":\"godrej-rhino-kl\",\"description\":\"A premium safe with modern lock mechanisms and high fire resistance.\",\"images\":[\"/images/100x/Godrej-Rhino-v1-1.webp\",\"/images/100x/Godrej-Rhino-v1-2.webp\"],\"tags\":[\"featured\"],\"lock_mechanism\":[\"keylock\"]},{\"id\":\"17\",\"name\":\"Godrej Ritz(Bio)\",\"price\":\"40,299\",\"size\":[\"(cm)33(h)x40(w)x32(d)\",\"(mm)330(h)x400(w)x320(d)\"],\"weight\":\"22.5kg\",\"volume\":\"30L\",\"category\":[\"100x\"],\"slug\":\"godrej-ritz-bio\",\"description\":\"A premium safe with modern lock mechanisms and high fire resistance.\",\"images\":[\"/images/100x/Godrej-Ritz-1.webp\",\"/images/100x/Godrej-Ritz-2.webp\"],\"tags\":[\"featured\"],\"lock_mechanism\":[\"biometric\"]},{\"id\":\"18\",\"name\":\"Godrej Ritz(Digi)\",\"price\":\"35,999\",\"size\":[\"(cm)33(h)x40(w)x32(d)\",\"(mm)330(h)x400(w)x320(d)\"],\"weight\":\"22.5kg\",\"volume\":\"30L\",\"category\":[\"100x\"],\"slug\":\"godrej-ritz-digi\",\"description\":\"A premium safe with modern lock mechanisms and high fire resistance.\",\"images\":[\"/images/100x/Godrej-Ritz-digi-1.webp\",\"/images/100x/Godrej-Ritz-digi-2.webp\"],\"tags\":[\"featured\"],\"lock_mechanism\":[\"digitel\"]},{\"id\":\"19\",\"name\":\"Godrej Citadel 45-v2(KL)\",\"price\":\"38,799\",\"size\":[\"(cm)47(h)x49(w)x45(d)\",\"(mm)470(h)x490(w)x450(d)\"],\"weight\":\"56kg\",\"volume\":\"42L\",\"category\":[\"100x\"],\"slug\":\"godrej-citadel-45-v2-kl\",\"description\":\"A premium safe with modern lock mechanisms and high fire resistance.\",\"images\":[\"/images/100x/Godrej-Citadel-1.webp\",\"/images/100x/Godrej-Citadel-2.webp\"],\"tags\":[\"featured\"],\"lock_mechanism\":[\"keylock\"]},{\"id\":\"20\",\"name\":\"MYST Big (Combination Lock)\",\"price\":\"1,199\",\"size\":[\"(cm)24.3(h)x15.9(w)x5.5(d)\",\"(mm)243(h)x159(w)x55(d)\"],\"weight\":\"0.78kg\",\"volume\":\"1.4L\",\"category\":[\"gift\"],\"slug\":\"myst-big\",\"description\":\"A premium safe with modern lock mechanisms and high fire resistance.\",\"images\":[\"/images/gift/myst-big-1.webp\",\"/images/gift/myst-big-2.webp\"],\"tags\":[],\"lock_mechanism\":[\"Combination Lock\"]},{\"id\":\"21\",\"name\":\"MYST Small (Combination Lock)\",\"price\":\"999\",\"size\":[\"(cm)18(h)x11.8(w)x5.5(d)\",\"(mm)180(h)x180(w)x55(d)\"],\"weight\":\"0.5kg\",\"volume\":\"0.7L\",\"category\":[\"gift\"],\"slug\":\"myst-small\",\"description\":\"A premium safe with modern lock mechanisms and high fire resistance.\",\"images\":[\"/images/gift/myst-small-1.webp\",\"/images/gift/myst-small-2.webp\"],\"tags\":[],\"lock_mechanism\":[\"Combination Lock\"]},{\"id\":\"22\",\"name\":\"Dream Box ( Blue )\",\"price\":\"4,499\",\"size\":[\"(cm)17(h)x23(w)x17(d)\",\"(mm)170(h)x230(w)x170(d)\"],\"weight\":\"2.5kg\",\"volume\":\"4.5L\",\"category\":[\"gift\"],\"slug\":\"dreambox-violet\",\"description\":\"A premium safe with modern lock mechanisms and high fire resistance.\",\"images\":[\"/images/gift/dreambox-blue-1.webp\",\"/images/gift/dreambox-blue-2.webp\"],\"tags\":[],\"lock_mechanism\":[\"digital\"]},{\"id\":\"23\",\"name\":\"Dream Box ( Pink )\",\"price\":\"4,499\",\"size\":[\"(cm)17(h)x23(w)x17(d)\",\"(mm)170(h)x230(w)x170(d)\"],\"weight\":\"2.5kg\",\"volume\":\"4.5L\",\"category\":[\"gift\"],\"slug\":\"dreambox-pink\",\"description\":\"A premium safe with modern lock mechanisms and high fire resistance.\",\"images\":[\"/images/gift/dreambox-pink-1.webp\",\"/images/gift/dreambox-pink-2.webp\"],\"tags\":[],\"lock_mechanism\":[\"digital\"]},{\"id\":\"24\",\"name\":\"Dream Box ( Black )\",\"price\":\"4,499\",\"size\":[\"(cm)17(h)x23(w)x17(d)\",\"(mm)170(h)x230(w)x170(d)\"],\"weight\":\"2.5kg\",\"volume\":\"4.5L\",\"category\":[\"gift\"],\"slug\":\"dreambox-black\",\"description\":\"A premium safe with modern lock mechanisms and high fire resistance.\",\"images\":[\"/images/gift/dreambox-black-1.webp\",\"/images/gift/dreambox-black-2.webp\"],\"tags\":[],\"lock_mechanism\":[\"digital\"]},{\"id\":\"25\",\"name\":\"Dream Box ( Red )\",\"price\":\"4,499\",\"size\":[\"(cm)17(h)x23(w)x17(d)\",\"(mm)170(h)x230(w)x170(d)\"],\"weight\":\"2.5kg\",\"volume\":\"4.5L\",\"category\":[\"gift\"],\"slug\":\"dreambox-red\",\"description\":\"A premium safe with modern lock mechanisms and high fire resistance.\",\"images\":[\"/images/gift/dreambox-red-1.webp\",\"/images/gift/dreambox-red-2.webp\"],\"tags\":[],\"lock_mechanism\":[\"digital\"]},{\"id\":\"26\",\"name\":\"Dream Box ( Keylock )\",\"price\":\"3,499\",\"size\":[\"(cm)17(h)x23(w)x17(d)\",\"(mm)170(h)x230(w)x170(d)\"],\"weight\":\"2.5kg\",\"volume\":\"4.5L\",\"category\":[\"gift\"],\"slug\":\"dreambox-keylock\",\"description\":\"A premium safe with modern lock mechanisms and high fire resistance.\",\"images\":[\"/images/gift/dreambox-kl-1.webp\",\"/images/gift/dreambox-kl-2.webp\"],\"tags\":[],\"lock_mechanism\":[\"digital\"]},{\"id\":\"27\",\"name\":\"Verge Biometric\",\"price\":\"13,499\",\"size\":[\"(cm)8.4(h)x34(w)x25.8(d)\",\"(mm)840(h)x340(w)x258(d)\"],\"weight\":\"4.5kg\",\"volume\":\"2L\",\"category\":[\"gift\"],\"slug\":\"verge-bio\",\"description\":\"A premium safe with modern lock mechanisms and high fire resistance.\",\"images\":[\"/images/gift/verge-bio-1.webp\",\"/images/gift/verge-bio-2.webp\"],\"tags\":[],\"lock_mechanism\":[\"biometric\"]},{\"id\":\"28\",\"name\":\"Verge Digital\",\"price\":\"13,000\",\"size\":[\"(cm)8.4(h)x34(w)x25.8(d)\",\"(mm)840(h)x340(w)x258(d)\"],\"weight\":\"4.5kg\",\"volume\":\"2L\",\"category\":[\"gift\"],\"slug\":\"verge-bio\",\"description\":\"A premium safe with modern lock mechanisms and high fire resistance.\",\"images\":[\"/images/gift/verge-bio-1.webp\",\"/images/gift/verge-bio-1.webp\"],\"tags\":[],\"lock_mechanism\":[\"digital\"]},{\"id\":\"29\",\"name\":\"Godrej Centiguard 1060 (Digi)\",\"price\":\"1,03,399\",\"size\":[\"(cm)125.4(h)x58(w)x58.7(d)\",\"(mm)1254(h)x580(w)x587(d)\"],\"weight\":\"236kg\",\"volume\":\"169L\",\"category\":[\"fire-resistant\"],\"slug\":\"godrej-centiguard-1060-digi\",\"description\":\"A premium safe with modern lock mechanisms and high fire resistance.\",\"images\":[\"/images/fire-resistant/godrej-centiguard-1060-digi-1.webp\",\"/images/fire-resistant/godrej-centiguard-1060-digi-2.webp\"],\"tags\":[],\"lock_mechanism\":[\"digital\"]},{\"id\":\"30\",\"name\":\"Godrej Centiguard 1060 (Keylock)\",\"price\":\"88,599\",\"size\":[\"(cm)125.4(h)x58(w)x58.7(d)\",\"(mm)1254(h)x580(w)x587(d)\"],\"weight\":\"236kg\",\"volume\":\"169L\",\"category\":[\"fire-resistant\"],\"slug\":\"godrej-centiguard-1060-keylock\",\"description\":\"A premium safe with modern lock mechanisms and high fire resistance.\",\"images\":[\"/images/fire-resistant/godrej-centiguard-1060-kl-1.webp\",\"/images/fire-resistant/godrej-centiguard-1060-kl-2.webp\"],\"tags\":[],\"lock_mechanism\":[\"keylock\"]},{\"id\":\"31\",\"name\":\"Godrej Centiguard 560 (Digi)\",\"price\":\"76,999\",\"size\":[\"(cm)75.4(h)x58(w)x58.7(d)\",\"(mm)754(h)x580(w)x587(d)\"],\"weight\":\"145kg\",\"volume\":\"89L\",\"category\":[\"fire-resistant\"],\"slug\":\"godrej-centiguard-560-digi\",\"description\":\"A premium safe with modern lock mechanisms and high fire resistance.\",\"images\":[\"/images/fire-resistant/godrej-centiguard-560-digi-1.webp\",\"/images/fire-resistant/godrej-centiguard-560-digi-2.webp\"],\"tags\":[],\"lock_mechanism\":[\"digital\"]},{\"id\":\"32\",\"name\":\"Godrej Centiguard 560 (keylock)\",\"price\":\"64,699\",\"size\":[\"(cm)75.4(h)x58(w)x58.7(d)\",\"(mm)754(h)x580(w)x587(d)\"],\"weight\":\"145kg\",\"volume\":\"89L\",\"category\":[\"fire-resistant\"],\"slug\":\"godrej-centiguard-560-keylock\",\"description\":\"A premium safe with modern lock mechanisms and high fire resistance.\",\"images\":[\"/images/fire-resistant/godrej-centiguard-560-kl-1.webp\",\"/images/fire-resistant/godrej-centiguard-560-kl-2.webp\"],\"tags\":[],\"lock_mechanism\":[\"keylock\"]},{\"id\":\"33\",\"name\":\"Godrej Centiguard 445 (keylock)\",\"price\":\"46,499\",\"size\":[\"(cm)63.9(h)x49.5(w)x53.7(d)\",\"(mm)639(h)x495(w)x537(d)\"],\"weight\":\"95kg\",\"volume\":\"49L\",\"category\":[\"fire-resistant\"],\"slug\":\"godrej-centiguard-445-kl\",\"description\":\"A premium safe with modern lock mechanisms and high fire resistance.\",\"images\":[\"/images/fire-resistant/godrej-centiguard-560-kl-1.webp\",\"/images/fire-resistant/godrej-centiguard-560-kl-2.webp\"],\"tags\":[],\"lock_mechanism\":[\"digital\"]},{\"id\":\"34\",\"name\":\"Godrej Safire 40L (Digi)\",\"price\":\"46,499\",\"size\":[\"(cm)56(h)x42.2(w)x49.1(d)\",\"(mm)560(h)x422(w)491(d)\"],\"weight\":\"61kg\",\"volume\":\"40L\",\"category\":[\"fire-resistant\"],\"slug\":\"godrej-safire-40l-digi\",\"description\":\"A premium safe with modern lock mechanisms and high fire resistance.\",\"images\":[\"/images/fire-resistant/godrej-safire-40l-digi-1.webp\",\"/images/fire-resistant/godrej-safire-40l-digi-2.webp\"],\"tags\":[],\"lock_mechanism\":[\"digital\"]},{\"id\":\"35\",\"name\":\"Godrej Safire 40L (keylock)\",\"price\":\"43,199\",\"size\":[\"(cm)56(h)x42.2(w)x49.1(d)\",\"(mm)560(h)x422(w)491(d)\"],\"weight\":\"61kg\",\"volume\":\"40L\",\"category\":[\"fire-resistant\"],\"slug\":\"godrej-safire-40l-keylock\",\"description\":\"A premium safe with modern lock mechanisms and high fire resistance.\",\"images\":[\"/images/fire-resistant/godrej-safire-40l-kl-1.webp\",\"/images/fire-resistant/godrej-safire-40l-kl-2.webp\"],\"tags\":[],\"lock_mechanism\":[\"keylock\"]},{\"id\":\"36\",\"name\":\"Godrej Safire 20L (keylock)\",\"price\":\"46,499\",\"size\":[\"(cm)44(h)x37.7(w)x43.1(d)\",\"(mm)440(h)x37.7(w)41(d)\"],\"weight\":\"40kg\",\"volume\":\"20L\",\"category\":[\"fire-resistant\"],\"slug\":\"godrej-safire-20l-keylock\",\"description\":\"A premium safe with modern lock mechanisms and high fire resistance.\",\"images\":[\"/images/fire-resistant/godrej-safire-40l-kl-1.webp\",\"/images/fire-resistant/godrej-safire-40l-kl-2.webp\"],\"tags\":[],\"lock_mechanism\":[\"keylock\"]},{\"id\":\"37\",\"name\":\"Godrej Nx Pro Luxe 48L(Digi+Bio)\",\"price\":\"47,999\",\"size\":[\"(cm)53(h)x40(w)x35(d)\",\"(mm)530(h)x400(w)x350(d)\"],\"weight\":\"29.5kg\",\"volume\":\"48L\",\"category\":[\"10x\"],\"slug\":\"godrej-nx-pro-luxe-48l-digi-bio\",\"description\":\"A premium safe with modern lock mechanisms and high fire resistance.\",\"images\":[\"/images/10x/godrej-nx-pro-luxe-48l-digi-bio-1.webp\",\"/images/10x/godrej-nx-pro-luxe-48l-digi-bio-2.webp\"],\"tags\":[\"featured\"],\"lock_mechanism\":[\"digital\",\"biometric\"]},{\"id\":\"38\",\"name\":\"Godrej Nx Pro luxe 30l(Digi+Bio)\",\"price\":\"38,599\",\"size\":[\"(cm)33(h)x40(w)x35(d)\",\"(mm)330(h)x400(w)x350(d)\"],\"weight\":\"20.9kg\",\"volume\":\"30L\",\"category\":[\"10x\"],\"slug\":\"godrej-nx-pro-luxe-30l-digi-bio\",\"description\":\"A premium safe with modern lock mechanisms and high fire resistance.\",\"images\":[\"/images/10x/godrej-nx-pro-luxe-30l-digi-bio-1.webp\",\"/images/10x/godrej-nx-pro-luxe-30l-digi-bio-2.webp\"],\"tags\":[\"featured\"],\"lock_mechanism\":[\"digital\",\"biometric\"]},{\"id\":\"39\",\"name\":\"Godrej Nx Pro Slide(Digi+Bio)\",\"price\":\"26,299\",\"size\":[\"(cm)19.5(h)x35.5(w)x400(d)\",\"(mm)195(h)x355(w)x400(d)\"],\"weight\":\"13.4kg\",\"volume\":\" 13L\",\"category\":[\"10x\"],\"slug\":\"godrej-nx-pro-slide-digi-bio\",\"description\":\"A premium safe with modern lock mechanisms and high fire resistance.\",\"images\":[\"/images/10x/godrej-nx-pro-slide-digi-bio-1.webp\",\"/images/10x/godrej-nx-pro-slide-digi-bio-2.webp\"],\"tags\":[\"featured\"],\"lock_mechanism\":[\"digital\",\"biometric\"]},{\"id\":\"40\",\"name\":\"Godrej Nx Pro Seal(KL)\",\"price\":\"16,599\",\"size\":[\"(cm)25(h)x35(w)x40(d)\",\"(mm)250(h)x350(w)x400(d)\"],\"weight\":\"15.6kg\",\"volume\":\" 25L\",\"category\":[\"10x\"],\"slug\":\"godrej-nx-pro-seal-kl\",\"description\":\"A premium safe with modern lock mechanisms and high fire resistance.\",\"images\":[\"/images/10x/godrej-nx-pro-seal-kl-1.webp\",\"/images/10x/godrej-nx-pro-seal-kl-2.webp\"],\"tags\":[\"featured\"],\"lock_mechanism\":[\"keylock\"]},{\"id\":\"41\",\"name\":\"Godrej Nx Pro Plus 70L(Digi+Bio)\",\"price\":\"46,299\",\"size\":[\"(cm)55.8(h)x37(w)x44.5(d)\",\"(mm)558(h)x370(w)x445(d)\"],\"weight\":\"27.1kg\",\"volume\":\"70L\",\"category\":[\"10x\"],\"slug\":\"godrej-nx-pro-plus-70l-digi-bio\",\"description\":\"A premium safe with modern lock mechanisms and high fire resistance.\",\"images\":[\"/images/10x/godrej-nx-pro-plus-70l-digi-bio-1.webp\",\"/images/10x/godrej-nx-pro-plus-70l-digi-bio-2.webp\"],\"tags\":[\"featured\"],\"lock_mechanism\":[\"digital\",\"biometric\"]},{\"id\":\"42\",\"name\":\"Godrej Nx Pro Plus 45L(Digi+Bio)\",\"price\":\"35,849\",\"size\":[\"(cm)50(h)x35.5(w)x33(d)\",\"(mm)500(h)x355(w)x330(d)\"],\"weight\":\"20.9kg\",\"volume\":\"45L\",\"category\":[\"10x\"],\"slug\":\"godrej-nx-pro-plus-45l-digi-bio\",\"description\":\"A premium safe with modern lock mechanisms and high fire resistance.\",\"images\":[\"/images/10x/godrej-nx-pro-plus-45l-digi-bio-1.webp\",\"/images/10x/godrej-nx-pro-plus-45l-digi-bio-2.webp\"],\"tags\":[\"featured\"],\"lock_mechanism\":[\"digital\",\"biometric\"]},{\"id\":\"43\",\"name\":\"Godrej Nx Pro Plus 30L(Digi+Bio)\",\"price\":\"27,599\",\"size\":[\"(cm)32(h)x40(w)x32(d)\",\"(mm)320(h)x400(w)x32(d)\"],\"weight\":\"15.8kg\",\"volume\":\"30L\",\"category\":[\"10x\"],\"slug\":\"godrej-nx-pro-plus-30l-digi-bio\",\"description\":\"A premium safe with modern lock mechanisms and high fire resistance.\",\"images\":[\"/images/10x/godrej-nx-pro-plus-30l-digi-bio-1.webp\",\"/images/10x/godrej-nx-pro-plus-30l-digi-bio-2.webp\"],\"tags\":[\"featured\"],\"lock_mechanism\":[\"digital\",\"biometric\"]},{\"id\":\"44\",\"name\":\"Godrej Nx Pro Plus 15L(Digi+Bio)\",\"price\":\"18,449\",\"size\":[\"(cm)25(h)x35(w)x25(d)\",\"(mm)250(h)x350(w)x250(d)\"],\"weight\":\"8.7kg\",\"volume\":\"15 L\",\"category\":[\"10x\"],\"slug\":\"godrej-nx-pro-plus-15l-digi-bio\",\"description\":\"A premium safe with modern lock mechanisms and high fire resistance.\",\"images\":[\"/images/10x/godrej-nx-pro-plus-15l-digi-bio-1.webp\",\"/images/10x/godrej-nx-pro-plus-15l-digi-bio-2.webp\"],\"tags\":[\"featured\"],\"lock_mechanism\":[\"digital\",\"biometric\"]},{\"id\":\"45\",\"name\":\"Godrej Nx Pro 40L(Digi)\",\"price\":\"23,599\",\"size\":[\"(cm)42(h)x35(w)x35(d)\",\"(mm)420(h)x350(w)x350(d)\"],\"weight\":\"16kg\",\"volume\":\"40L\",\"category\":[\"10x\"],\"slug\":\"godrej-nx-pro-40l-digi\",\"description\":\"A premium safe with modern lock mechanisms and high fire resistance.\",\"images\":[\"/images/10x/godrej-nx-pro-40l-digi-1.webp\",\"/images/10x/godrej-nx-pro-40l-digi-2.webp\"],\"tags\":[\"featured\"],\"lock_mechanism\":[\"digital\"]},{\"id\":\"46\",\"name\":\"Godrej Nx Pro 30L(Digi)\",\"price\":\"21,299\",\"size\":[\"(cm)32(h)x40(w)x32(d)\",\"(mm)320(h)x400(w)x320(d)\"],\"weight\":\"13kg\",\"volume\":\"30L\",\"category\":[\"10x\"],\"slug\":\"godrej-nx-pro-30l-digi\",\"description\":\"A premium safe with modern lock mechanisms and high fire resistance.\",\"images\":[\"/images/10x/godrej-nx-pro-30l-digi-1.webp\",\"/images/10x/godrej-nx-pro-30l-digi-2.webp\"],\"tags\":[\"featured\"],\"lock_mechanism\":[\"digital\"]},{\"id\":\"47\",\"name\":\"Godrej Nx Pro 25L(Digi)\",\"price\":\"18,199\",\"size\":[\"(cm)20(h)x42(w)x37(d)\",\"(mm)200(h)x420(w)x370(d)\"],\"weight\":\"11kg\",\"volume\":\"25L\",\"category\":[\"10x\"],\"slug\":\"godrej-nx-pro-25l-digi\",\"description\":\"A premium safe with modern lock mechanisms and high fire resistance.\",\"images\":[\"/images/10x/godrej-nx-pro-25l-digi-1.webp\",\"/images/10x/godrej-nx-pro-25l-digi-2.webp\"],\"tags\":[\"featured\"],\"lock_mechanism\":[\"digital\"]},{\"id\":\"48\",\"name\":\"Godrej Nx Pro 15L(Digi)\",\"price\":\"12,899\",\"size\":[\"(cm)25(h)x35(w)x25(d)\",\"(mm)250(h)x350(w)x250(d)\"],\"weight\":\"9kg\",\"volume\":\"15L\",\"category\":[\"10x\"],\"slug\":\"godrej-nx-pro-15l-digi\",\"description\":\"A premium safe with modern lock mechanisms and high fire resistance.\",\"images\":[\"/images/10x/godrej-nx-pro-15l-digi-1.webp\",\"/images/10x/godrej-nx-pro-15l-digi-2.webp\"],\"tags\":[\"featured\"],\"lock_mechanism\":[\"digital\"]},{\"id\":\"49\",\"name\":\"Godrej Nx Pro 8L(Digi)\",\"price\":\"10,699\",\"size\":[\"(cm)20(h)x30(w)x20(d)\",\"(mm)200(h)x300(w)x200(d)\"],\"weight\":\"5kg\",\"volume\":\"8L\",\"category\":[\"10x\"],\"slug\":\"godrej-nx-pro-8l-digi\",\"description\":\"A premium safe with modern lock mechanisms and high fire resistance.\",\"images\":[\"/images/10x/godrej-nx-pro-8l-digi-1.webp\",\"/images/10x/godrej-nx-pro-8l-digi-2.webp\"],\"tags\":[\"featured\"],\"lock_mechanism\":[\"digital\"]},{\"id\":\"50\",\"name\":\"Godrej Nx Pro 33L(KL)\",\"price\":\"18,399\",\"size\":[\"(cm)25(h)x45.5(w)x37.5(d)\",\"(mm)250(h)455x(w)x375(d)\"],\"weight\":\"14.5kg\",\"volume\":\"33L\",\"category\":[\"10x\"],\"slug\":\"godrej-nx-pro-33l-kl\",\"description\":\"A premium safe with modern lock mechanisms and high fire resistance.\",\"images\":[\"/images/10x/Godrej-nx-pro-33l-kl-1.webp\",\"/images/10x/Godrej-nx-pro-33l-kl-2.webp\"],\"tags\":[\"featured\"],\"lock_mechanism\":[\"keylock\"]},{\"id\":\"51\",\"name\":\"Godrej Nx Pro 15L(KL)\",\"price\":\"9,099\",\"size\":[\"(cm)25(h)x35(w)x25(d)\",\"(mm)250(h)x350(w)x250(d)\"],\"weight\":\"9kg\",\"volume\":\"15L\",\"category\":[\"10x\"],\"slug\":\"godrej-nx-pro-15l-kl\",\"description\":\"A premium safe with modern lock mechanisms and high fire resistance.\",\"images\":[\"/images/10x/Godrej-nx-pro-15l-kl-1.webp\",\"/images/10x/Godrej-nx-pro-15l-kl-2.webp\"],\"tags\":[\"featured\"],\"lock_mechanism\":[\"keylock\"]},{\"id\":\"52\",\"name\":\"Godrej E-Swipe(Digi)\",\"price\":\"26,699\",\"size\":[\"(cm)25(h)x45.5(w)x37.5(d)\",\"(mm)250(h)x400(w)x375(d)\"],\"weight\":\"15.5kg\",\"volume\":\"35L\",\"category\":[\"10x\"],\"slug\":\"godrej-e-swipe-digi\",\"description\":\"A premium safe with modern lock mechanisms and high fire resistance.\",\"images\":[\"/images/10x/Godrej-e-swipe-digi-1.webp\",\"/images/10x/Godrej-e-swipe-digi-2.webp\"],\"tags\":[\"featured\"],\"lock_mechanism\":[\"digitel\"]},{\"id\":\"53\",\"name\":\"Godrej Premium Coffer(KL)\",\"price\":\"14,899\",\"size\":[\"(cm)25.4(h)x36.2(w)x34(d)\",\"(mm)254(h)x362(w)x340(d)\"],\"weight\":\"12.5kg\",\"volume\":\"22L\",\"category\":[\"10x\"],\"slug\":\"godrej-premium-coffer-kl\",\"description\":\"A premium safe with modern lock mechanisms and high fire resistance.\",\"images\":[\"/images/10x/Godrej-premium-coffer-kl-1.webp\",\"/images/10x/Godrej-premium-coffer-kl-2.webp\"],\"tags\":[\"featured\"],\"lock_mechanism\":[\"keylock\"]},{\"id\":\"54\",\"name\":\"Godrej Cashbox(KL)\",\"price\":\"12,299\",\"size\":[\"(cm)15.1(h)x35.6(w)x25.4(d)\",\"(mm)151(h)x356(w)x254(d)\"],\"weight\":\"13.7kg\",\"volume\":\"6.3L\",\"category\":[\"10x\"],\"slug\":\"godrej-cashbox-kl\",\"description\":\"A premium safe with modern lock mechanisms and high fire resistance.\",\"images\":[\"/images/10x/Godrej-cashbox-1.webp\",\"/images/10x/Godrej-cashbox-2.webp\"],\"tags\":[\"featured\"],\"lock_mechanism\":[\"keylock\"]},{\"id\":\"55\",\"name\":\"Godrej Privy(Digi)\",\"price\":\"22,499\",\"size\":[\"(cm)18(h)x40(w)x35(d)\",\"(mm)180(h)x400(w)x350(d)\"],\"weight\":\"13kg\",\"volume\":\"25L\",\"category\":[\"10x\"],\"slug\":\"godrej-privy-digi\",\"description\":\"A premium safe with modern lock mechanisms and high fire resistance.\",\"images\":[\"/images/10x/Godrej-privy-1.webp\",\"/images/10x/Godrej-privy-2.webp\"],\"tags\":[\"featured\"],\"lock_mechanism\":[\"digital\"]},{\"id\":\"56\",\"name\":\"Godrej  Nx key Storage Locker(KL)\",\"price\":\"16,298\",\"size\":[\"(cm)36(h)x30(w)x10(d)\",\"(mm)360(h)x300(w)x100(d)\"],\"weight\":\"7.3kg\",\"volume\":\"6.4L\",\"category\":[\"10x\"],\"slug\":\"godrej-nx-key-storage-locker\",\"description\":\"A premium safe with modern lock mechanisms and high fire resistance.\",\"images\":[\"/images/10x/Godrej-nx-keylocker-1.webp\",\"/images/10x/Godrej-nx-keylocker-2.webp\"],\"tags\":[\"featured\"],\"lock_mechanism\":[\"keylock\"]}]"));}),
"[project]/components/FeaturedProductsCarousel.tsx [app-rsc] (client reference proxy) <module evaluation>": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$6_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.6_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$6_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/components/FeaturedProductsCarousel.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/components/FeaturedProductsCarousel.tsx <module evaluation>", "default");
}),
"[project]/components/FeaturedProductsCarousel.tsx [app-rsc] (client reference proxy)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$6_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.6_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$6_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/components/FeaturedProductsCarousel.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/components/FeaturedProductsCarousel.tsx", "default");
}),
"[project]/components/FeaturedProductsCarousel.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$FeaturedProductsCarousel$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/components/FeaturedProductsCarousel.tsx [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$FeaturedProductsCarousel$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/components/FeaturedProductsCarousel.tsx [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$FeaturedProductsCarousel$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/components/HeroSection.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

// components/HeroSection.tsx
__turbopack_context__.s({
    "default": ()=>HeroSection
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$6_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.6_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$6_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.6_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/image.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$6_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.6_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/client/app-dir/link.js [app-rsc] (ecmascript)");
;
;
;
function HeroSection({ title, description, primaryText, primaryLink, secondaryText, secondaryLink, imageSrc, reverse = false }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$6_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "grid grid-cols-1 md:grid-cols-2 items-center max-w-7xl py-10 mx-auto px-5 gap-6",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$6_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `bg-gray-100 p-6 md:p-8 rounded-lg flex flex-col justify-center text-center md:text-left
          order-2 ${reverse ? "md:order-2" : "md:order-1"}`,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$6_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "text-2xl md:text-3xl font-bold text-gray-800 mb-4",
                        children: title
                    }, void 0, false, {
                        fileName: "[project]/components/HeroSection.tsx",
                        lineNumber: 34,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$6_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-gray-600 text-base md:text-lg mb-6",
                        children: description
                    }, void 0, false, {
                        fileName: "[project]/components/HeroSection.tsx",
                        lineNumber: 35,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$6_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-wrap justify-center md:justify-start gap-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$6_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$6_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                                href: primaryLink,
                                className: "px-6 py-3 bg-blue-600 text-white rounded-md font-medium shadow hover:bg-blue-700 transition",
                                children: primaryText
                            }, void 0, false, {
                                fileName: "[project]/components/HeroSection.tsx",
                                lineNumber: 39,
                                columnNumber: 11
                            }, this),
                            secondaryText && secondaryLink && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$6_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$6_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                                href: secondaryLink,
                                className: "px-6 py-3 bg-gray-200 text-gray-800 rounded-md font-medium shadow hover:bg-gray-300 transition",
                                children: secondaryText
                            }, void 0, false, {
                                fileName: "[project]/components/HeroSection.tsx",
                                lineNumber: 46,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/HeroSection.tsx",
                        lineNumber: 38,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/HeroSection.tsx",
                lineNumber: 30,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$6_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `relative w-full order-1 flex justify-center ${reverse ? "md:order-1" : "md:order-2"}`,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$6_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$6_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                    src: imageSrc,
                    alt: title,
                    width: 1080,
                    height: 1350,
                    priority: true,
                    fetchPriority: "high",
                    sizes: "(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw",
                    className: "w-full max-w-full h-auto object-contain rounded-lg",
                    quality: 80,
                    placeholder: "blur",
                    blurDataURL: "/images/placeholder.png",
                    style: {
                        maxHeight: "550px",
                        margin: "0 auto"
                    }
                }, void 0, false, {
                    fileName: "[project]/components/HeroSection.tsx",
                    lineNumber: 60,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/HeroSection.tsx",
                lineNumber: 57,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/HeroSection.tsx",
        lineNumber: 27,
        columnNumber: 5
    }, this);
}
}),
"[project]/components/FAQSection.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "default": ()=>FAQSection
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$6_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.6_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
;
function FAQSection() {
    const faqs = [
        {
            question: "What products do you specialize in?",
            answer: "We provide Godrej Security Solutions including Safe Lockers, CCTV Systems, Video Door Phones, and Digital Locks."
        },
        {
            question: "Do you offer installation services?",
            answer: "Yes, our team provides complete installation and support for all security systems purchased from us."
        },
        {
            question: "How can I contact your team?",
            answer: "You can call us directly or reach us via WhatsApp. Visit the Contact section for quick access."
        },
        {
            question: "Do you provide warranty on products?",
            answer: "All our products come with official brand warranty and after-sales support."
        }
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$6_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "w-full bg-gray-50 py-12",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$6_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "max-w-4xl mx-auto px-4",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$6_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                    className: "text-3xl font-bold text-gray-900 mb-8 text-center",
                    children: "Frequently Asked Questions"
                }, void 0, false, {
                    fileName: "[project]/components/FAQSection.tsx",
                    lineNumber: 28,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$6_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "divide-y divide-gray-200",
                    children: faqs.map((faq, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$6_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("details", {
                            className: "group py-4 cursor-pointer",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$6_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("summary", {
                                    className: "flex justify-between items-center font-medium text-gray-800 hover:text-blue-600",
                                    children: [
                                        faq.question,
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$6_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "transition-transform duration-300 group-open:rotate-180",
                                            children: "▼"
                                        }, void 0, false, {
                                            fileName: "[project]/components/FAQSection.tsx",
                                            lineNumber: 39,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/FAQSection.tsx",
                                    lineNumber: 37,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$6_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "mt-2 text-gray-600 leading-relaxed",
                                    children: faq.answer
                                }, void 0, false, {
                                    fileName: "[project]/components/FAQSection.tsx",
                                    lineNumber: 43,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, index, true, {
                            fileName: "[project]/components/FAQSection.tsx",
                            lineNumber: 33,
                            columnNumber: 13
                        }, this))
                }, void 0, false, {
                    fileName: "[project]/components/FAQSection.tsx",
                    lineNumber: 31,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/FAQSection.tsx",
            lineNumber: 27,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/FAQSection.tsx",
        lineNumber: 26,
        columnNumber: 5
    }, this);
}
}),
"[project]/components/StickyCTA.tsx [app-rsc] (client reference proxy) <module evaluation>": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$6_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.6_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$6_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/components/StickyCTA.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/components/StickyCTA.tsx <module evaluation>", "default");
}),
"[project]/components/StickyCTA.tsx [app-rsc] (client reference proxy)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$6_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.6_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$6_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/components/StickyCTA.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/components/StickyCTA.tsx", "default");
}),
"[project]/components/StickyCTA.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$StickyCTA$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/components/StickyCTA.tsx [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$StickyCTA$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/components/StickyCTA.tsx [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$StickyCTA$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/components/CategoryShowcase.tsx [app-rsc] (client reference proxy) <module evaluation>": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$6_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.6_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$6_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/components/CategoryShowcase.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/components/CategoryShowcase.tsx <module evaluation>", "default");
}),
"[project]/components/CategoryShowcase.tsx [app-rsc] (client reference proxy)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$6_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.6_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$6_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/components/CategoryShowcase.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/components/CategoryShowcase.tsx", "default");
}),
"[project]/components/CategoryShowcase.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$CategoryShowcase$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/components/CategoryShowcase.tsx [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$CategoryShowcase$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/components/CategoryShowcase.tsx [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$CategoryShowcase$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/app/page.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "default": ()=>Home,
    "dynamic": ()=>dynamic
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$6_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.6_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$products$2e$json__$28$json$29$__ = __turbopack_context__.i("[project]/data/products.json (json)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$FeaturedProductsCarousel$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/FeaturedProductsCarousel.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$HeroSection$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/HeroSection.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$FAQSection$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/FAQSection.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$StickyCTA$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/StickyCTA.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$CategoryShowcase$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/CategoryShowcase.tsx [app-rsc] (ecmascript)");
;
;
;
;
;
;
;
const categorie = [
    {
        name: "250x Safes",
        slug: "250x",
        image: "/images/250x/Godrej-Matrix-3016-1.webp"
    },
    {
        name: "100x Safes",
        slug: "100x",
        image: "/images/100x/Godrej-Rhino-advanced-1.webp"
    },
    {
        name: "10x",
        slug: "10x",
        image: "/images/100x/Godrej-Citadel-1.webp"
    },
    {
        name: "Gifts",
        slug: "gift",
        image: "/images/gift/dreambox-red-1.webp"
    },
    {
        name: "Fire Proof",
        slug: "fire-resistant",
        image: "/images/fire-resistant/godrej-safire-40l-digi-1.webp"
    }
];
const dynamic = "force-static";
const slides = [
    {
        title: "Secure Your Home Today",
        description: "Explore Godrej lockers for ultimate home security.",
        imageSrc: "/images/hero/Liquid-cash.png",
        buttonText: "Shop Now",
        buttonLink: "/products"
    }
];
function Home() {
    const featuredProducts = __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$products$2e$json__$28$json$29$__["default"].filter((p)=>p.tags?.includes("featured"));
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$6_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$6_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$6_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$HeroSection$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                title: "250X Lockers",
                description: "SafeGuard your precious valuables with confidence and peace of mind with our trusted, strongest and most secure lockers with double walls and patented construction. The best in class - unmatched protection for your valuables.",
                primaryText: "View Lockers",
                primaryLink: "/products/250x",
                // secondaryText="Contact Us"
                // secondaryLink="/contact"
                imageSrc: "/images/hero/1.webp",
                reverse: true
            }, void 0, false, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 59,
                columnNumber: 1
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$6_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$HeroSection$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                title: "Fire Resistant Lockers",
                description: "Ensure standard strength security for your valuables. while these lockers offer a basic level of burglary resistant protection, for enhanced security, we strongly recommend our advanced and extreme strength models. with advanced features and reinforced constuction, they provide superior protection for your valuables",
                primaryText: "View Lockers",
                primaryLink: "/products/fire-resistant",
                imageSrc: "/images/hero/4.webp"
            }, void 0, false, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 71,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$6_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$HeroSection$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                title: "100x Lockers",
                description: "Heightened Protection for your valuables with innovative single wall reinforcement technology. Each Locker features fortified walls, powered by state-of-the-art technology for maximum security, ensuring peace of mind.",
                primaryText: "View Lockers",
                primaryLink: "/products/100x",
                imageSrc: "/images/hero/2.webp",
                reverse: true
            }, void 0, false, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 81,
                columnNumber: 2
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$6_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$HeroSection$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                title: "10X Lockers",
                description: "Ensure standard strength security for your valuables. while these lockers offer a basic level of burglary resistant protection, for enhanced security, we strongly recommend our advanced and extreme strength models. with advanced features and reinforced constuction, they provide superior protection for your valuables",
                primaryText: "Explore Products",
                primaryLink: "/products/10x",
                imageSrc: "/images/hero/3.webp"
            }, void 0, false, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 90,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$6_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$CategoryShowcase$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                categories: categorie
            }, void 0, false, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 104,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$6_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$FAQSection$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 106,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$6_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$FeaturedProductsCarousel$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                products: featuredProducts
            }, void 0, false, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 108,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$6_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$StickyCTA$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                phoneNumber: "+917550084414",
                whatsappNumber: "+917550084414"
            }, void 0, false, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 110,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
}),
"[project]/app/page.tsx [app-rsc] (ecmascript, Next.js Server Component)": ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/page.tsx [app-rsc] (ecmascript)"));
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__bbec1ab6._.js.map